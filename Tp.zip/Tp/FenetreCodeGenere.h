#ifndef FENETRECODEGENERE_H
#define FENETRECODEGENERE_H
#include<QtWidgets>


class FenetreCodeGenere:public QDialog
  {
    public:
        FenetreCodeGenere(QString &code,QWidget *parent);

    private:
        QTextEdit *m_codeGenere;
        QPushButton *m_fermer;
   };




#endif // FENETRECODEGENERE_H
