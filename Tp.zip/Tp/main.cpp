#include<QApplication>
#include<QWidget>
#include"FenetrePrincipale.h"
int main(int argc, char *argv[])

{
    QApplication app(argc,argv);
    FenetrePrincipale fenetre;
    fenetre.setWindowTitle("Avine Dev's Classe generator");
    fenetre.show();



    return app.exec();
}
