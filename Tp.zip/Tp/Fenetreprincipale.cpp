#include"FenetrePrincipale.h"
#include<FenetreCodeGenere.h>

 void FenetrePrincipale::GenererCode()
    {
      QString code;
      QString mere;
      QString commentaire;
      QString destructeur;
      QString constructeur;
      QString header;
      QString footer;
    if(m_nom->text().isEmpty())
        {
        QMessageBox::critical(this,"Erreur","Vous devez nécessairement renseigner un nom de classe");
        return;
    }else
        {
            //classe mèere
            if(!m_classeMere->text().isEmpty())
            {
                mere=("public "+m_classeMere->text());
            }else{mere=QString("");}
            //destructur et constructeur
            if(!m_genererDestruct->isChecked())
            {
                destructeur=QString("");
            }else{destructeur=QString("~"+m_nom->text()+"\(\);");}
            if(!m_genererConstructeur->isChecked())
            {
                constructeur=QString("");
            }else{constructeur=QString(m_nom->text()+"\(\);");}

            //protections de header
            if(!m_protections->isChecked())
            {
                header=QString("");
            }else{header=QString("#ifndef HEADER_"+m_nom->text().toUpper()+"\n#define HEADER_"+m_nom->text().toUpper()+"\n");}

            //Ajout commentaires
            if(m_groupeCommentaires->isChecked())
            {
                QString auteur;
                QString date;
                QString role;

                if(!m_auteur->text().isEmpty())
                {
                    auteur=m_auteur->text().toUpper();
                }else{auteur=QString("");}
                if(m_role->toPlainText().isEmpty())
                {
                    role=QString("");
                }else{role=m_role->toPlainText();}


                commentaire=QString("\/*\n Auteur: "+auteur+"\n Date de création:"+m_dateCreation->date().toString()+"\n\nRôle :"+role+"\n*\/ \n");


            }else{commentaire=QString("");}
            footer=QString("\n    protected:\n\n    private:");


            code=QString(commentaire+header+"class "+m_nom->text()+":"+mere+" \n\{\n"+"   "+"public:\n"+"      "+constructeur+"\n"+"      "+destructeur+footer+"\n\};");

        }
    FenetreCodeGenere *fenetreCode=new FenetreCodeGenere(code,this);
    fenetreCode->exec();
    }






FenetrePrincipale::FenetrePrincipale()
    {
        //cretion de widget et layout
//info géné
   QGroupBox *m_infogene =new QGroupBox("Informations générales");
    m_nom= new QLineEdit;
    m_classeMere =new QLineEdit;
    QFormLayout *formlayout=new QFormLayout;
    formlayout->addRow("Nom:",m_nom);
    formlayout->addRow("Classe mère:",m_classeMere);
    QVBoxLayout *layoutInfo=new QVBoxLayout;
    layoutInfo->addLayout(formlayout);
    m_infogene->setLayout(layoutInfo);

    //options

    QGroupBox *m_options= new QGroupBox("Options");
    m_protections=new QCheckBox("Protéger le header contre les inclusions multiples");
    m_genererConstructeur=new QCheckBox("Générer un constructeur par défaut");
    m_genererDestruct=new QCheckBox("Générer un destructeur");
    QVBoxLayout *layoutoptions=new QVBoxLayout;
    layoutoptions->addWidget(m_protections);
    layoutoptions->addWidget(m_genererConstructeur);
    layoutoptions->addWidget(m_genererDestruct);
    m_options->setLayout(layoutoptions);


    //ajout commentaires
    m_groupeCommentaires=new QGroupBox();
    m_groupeCommentaires->isCheckable();
    m_groupeCommentaires->setTitle("Ajouter commentaires");
    m_groupeCommentaires->setCheckable(true);
    m_groupeCommentaires->setChecked(false);

    m_auteur=new QLineEdit();
    m_dateCreation=new QDateEdit();
    m_role=new QTextEdit();
    QFormLayout *formlayout2=new QFormLayout;
    formlayout2->addRow("Auteur: ",m_auteur);
    formlayout2->addRow("Date de création :",m_dateCreation);
    formlayout2->addRow("Rôle de la classe: ",m_role);
    QVBoxLayout *layoutcommentaires=new QVBoxLayout;
    layoutcommentaires->addLayout(formlayout2);
    layoutcommentaires->addStretch(1);
    m_groupeCommentaires->setLayout(layoutcommentaires);

    //quitter et générer
    m_quitter=new QPushButton("quitter");
    m_generer=new QPushButton("Générer");
    QHBoxLayout *quitterOugenerer=new QHBoxLayout;
    quitterOugenerer->addWidget(m_generer);
    quitterOugenerer->addWidget(m_quitter);
    //layout de la page
    QVBoxLayout *layoutPrincipal= new QVBoxLayout(this);
    layoutPrincipal->addWidget(m_infogene);
    layoutPrincipal->addWidget(m_options);
    layoutPrincipal->addWidget(m_groupeCommentaires);
    layoutPrincipal->addLayout(quitterOugenerer);
//connection des buttons
    QObject::connect(m_quitter,SIGNAL(clicked()),qApp,SLOT(quit()));
    QObject::connect(m_generer,SIGNAL(clicked()),this,SLOT(GenererCode()));


    }










