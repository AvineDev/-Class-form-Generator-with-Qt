#include<FenetreCodeGenere.h>
FenetreCodeGenere::FenetreCodeGenere(QString &code,QWidget *parent=0):
QDialog(parent)
{
    m_codeGenere=new QTextEdit();
    m_codeGenere->setPlainText(code);
    m_codeGenere->setReadOnly(true);
    m_codeGenere->setFont(QFont("Courier"));
    m_codeGenere->setLineWrapMode(QTextEdit::NoWrap);
    m_fermer=new QPushButton("Fermer");

    //layout
    QVBoxLayout *layoutprincipal=new QVBoxLayout;
    layoutprincipal->addWidget(m_codeGenere);
    layoutprincipal->addWidget(m_fermer);
    resize(350,450);
    this->setLayout(layoutprincipal);

    connect(m_fermer,SIGNAL(clicked()),this,SLOT(accept()));



}
