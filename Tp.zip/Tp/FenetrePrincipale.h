#ifndef FENETREPRINCIPALE_H
#define FENETREPRINCIPALE_H
#include<QtWidgets>

class FenetrePrincipale: public QWidget
    {
        Q_OBJECT
        public:
            FenetrePrincipale();
       private slots:
             void GenererCode();
        private:
             QLineEdit *m_nom;
             QLineEdit *m_classeMere;
             QCheckBox *m_protections;
             QCheckBox *m_genererConstructeur;
             QCheckBox *m_genererDestruct;
             QGroupBox *m_groupeCommentaires;
             QLineEdit *m_auteur;
             QDateEdit *m_dateCreation;
             QTextEdit *m_role;
             QPushButton *m_quitter;
             QPushButton *m_generer;



    };


#endif // FENETREPRINCIPALE_H
